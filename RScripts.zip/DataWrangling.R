# import packages
library(tidyverse)
library(stringi)
library(zoo)
library(foreign)


# import external datasets which come to use in the wrangling
data_us_states <- read_csv("locations/USA_states.csv") %>% select(abbreviation = abbrevation, state)
data_continents <- read_csv("locations/continents-according-to-our-world-in-data.csv")
exchange_aud <- read_csv("exchange-rates/AUD_USD Historical Data.csv") %>% select(Date, Price_AUD = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_cad <- read_csv("exchange-rates/CAD_USD Historical Data.csv") %>% select(Date, Price_CAD = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_chf <- read_csv("exchange-rates/CHF_USD Historical Data.csv") %>% select(Date, Price_CHF = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_dkk <- read_csv("exchange-rates/DKK_USD Historical Data.csv") %>% select(Date, Price_DKK = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_eur <- read_csv("exchange-rates/EUR_USD Historical Data.csv") %>% select(Date, Price_EUR = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_gbp <- read_csv("exchange-rates/GBP_USD Historical Data.csv") %>% select(Date, Price_GBP = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_hkd <- read_csv("exchange-rates/HKD_USD Historical Data.csv") %>% select(Date, Price_HKD = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_jpy <- read_csv("exchange-rates/JPY_USD Historical Data.csv") %>% select(Date, Price_JPY = Price) %>% mutate(Date = mdy(Date)) %>% mutate(Price_JPY = Price_JPY/100) %>% arrange(Date)
exchange_mxn <- read_csv("exchange-rates/MXN_USD Historical Data.csv") %>% select(Date, Price_MXN = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_nok <- read_csv("exchange-rates/NOK_USD Historical Data.csv") %>% select(Date, Price_NOK = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_nzd <- read_csv("exchange-rates/NZD_USD Historical Data.csv") %>% select(Date, Price_NZD = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_sek <- read_csv("exchange-rates/SEK_USD Historical Data.csv") %>% select(Date, Price_SEK = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_pln <- read_csv("exchange-rates/PLN_USD Historical Data.csv") %>% select(Date, Price_PLN = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)
exchange_sgd <- read_csv("exchange-rates/SGD_USD Historical Data.csv") %>% select(Date, Price_SGD = Price) %>% mutate(Date = mdy(Date)) %>% arrange(Date)


# import Kickstarter project campaign site data (fail because internet connection got lost during scraping these sites)
data_kickstarter_campaign1 <- read_csv("v1_0-199/raw-data-project.csv")
data_kickstarter_campaign2 <- read_csv("v2_200-2199/raw-data-project.csv")
data_kickstarter_campaign3 <- read_csv("v3_2200-2699/raw-data-project.csv")
data_kickstarter_campaign4 <- read_csv("v4_2700-3199/raw-data-project.csv")
data_kickstarter_campaign5 <- read_csv("v5_3200-3699/raw-data-project.csv")
data_kickstarter_campaign6 <- read_csv("v6_3700-4199_fail/raw-data-project.csv")
data_kickstarter_campaign7 <- read_csv("v7_4200-5200/raw-data-project.csv")
data_kickstarter_campaign8 <- read_csv("v8_5200-10200/raw-data-project.csv")
data_kickstarter_campaign9 <- read_csv("v9_10200-11950_fail/raw-data-project.csv")
data_kickstarter_campaign10 <- read_csv("v10_11950-13450/raw-data-project.csv")
data_kickstarter_campaign11 <- read_csv("v11_13450-23450/raw-data-project.csv")
data_kickstarter_campaign12 <- read_csv("v12_23450-27450/raw-data-project.csv")


# combine these datasets to a single dataset
data_project_campaign <- rbind(data_kickstarter_campaign1, data_kickstarter_campaign2, data_kickstarter_campaign3, data_kickstarter_campaign4, data_kickstarter_campaign5,
                         data_kickstarter_campaign6, data_kickstarter_campaign7, data_kickstarter_campaign8, data_kickstarter_campaign9,
                         data_kickstarter_campaign10, data_kickstarter_campaign11, data_kickstarter_campaign12)


# remove all missing and duplicated values within the dataset
data_project_campaign <- data_project_campaign %>% na.omit() %>% 
  distinct(kickstarter_link, .keep_all = TRUE)


# formatting of the details column
details_to_list <- function(s) {
  # remove apostrophes in between of letters
  s <- gsub("(?<=[A-Za-z])'(?=[A-Za-z])", "", s, perl = TRUE)
  # extract text in between of quotation marks
  matches <- str_match_all(s, "(?<![A-Za-z])(['\"])([^'\"]*?)\\1(?![A-Za-z])")
  # combine the extract text without quotation marks
  extracted_items <- matches[[1]][, 3]
  # remove "\\n"
  cleaned_items <- gsub("\\\\n", "", extracted_items)
}

data_project_campaign$details <- sapply(data_project_campaign$details, details_to_list)


# formatting of the reward column
format_reward <- function(string) {
  # remove square brackets
  string <- substr(string, 3, nchar(string) - 2)
  # separate the inner lists
  elements <- strsplit(string, "\\], \\[")[[1]]
  # replace quotation marks
  formatted_elements <- gsub("'", "", elements)
  formatted_elements <- gsub('"', "", formatted_elements)
  # combine the elements
  formatted_string <- paste("[", formatted_elements, "]", sep = "")
}

formatted_reward <- sapply(data_project_campaign$reward, format_reward)

# combine the extracted elements into a vector
formatted_vector <- unname(c(formatted_reward))

# replace the reward column with the new formatted vector
data_project_campaign$reward <- formatted_vector


# function to calculate the length of vectors
calculate_length <- function(vector) {
  return(length(vector))
}


# clean the complete dataset
data_project_campaign <- data_project_campaign %>% 
  mutate(team_favorite = ifelse((sapply(details, `[`, 1) == "Zine Quest" | sapply(details, `[`, 1) == "Make 100" | sapply(details, `[`, 1) == "Witchstarter" | sapply(details, `[`, 1) == "Long Story Short" | sapply(details, `[`, 1) == "Heartstrings & Hardbacks"),
                                ifelse(sapply(details, `[`, 2) == "Project We Love",
                                       1,
                                       0),
                                ifelse(sapply(details, `[`, 1) == "Project We Love",
                                       1,
                                       0))) %>%
  mutate(open_call = ifelse((sapply(details, `[`, 1) == "Zine Quest" | sapply(details, `[`, 1) == "Make 100" | sapply(details, `[`, 1) == "Witchstarter" | sapply(details, `[`, 1) == "Long Story Short" | sapply(details, `[`, 1) == "Heartstrings & Hardbacks"),
                            sapply(details, `[`, 1),
                            "None")) %>%
  mutate(category = ifelse((sapply(details, `[`, 1) == "Zine Quest" | sapply(details, `[`, 1) == "Make 100" | sapply(details, `[`, 1) == "Witchstarter" | sapply(details, `[`, 1) == "Long Story Short" | sapply(details, `[`, 1) == "Heartstrings & Hardbacks"),
                           ifelse((state == "Funding Unsuccessful" | state == "Funding Suspended" | state == "Funding Canceled"),
                                  ifelse(sapply(details, `[`, 2) == "Project We Love",
                                         sapply(details, `[`, 3),
                                         sapply(details, `[`, 2)),
                                  ifelse(sapply(details, `[`, 2) == "Project We Love",
                                         sapply(details, `[`, 4),
                                         sapply(details, `[`, 3))),
                           ifelse((state == "Funding Unsuccessful" | state == "Funding Suspended" | state == "Funding Canceled"),
                                  ifelse(sapply(details, `[`, 1) == "Project We Love",
                                         sapply(details, `[`, 2),
                                         sapply(details, `[`, 1)),
                                  ifelse(sapply(details, `[`, 1) == "Project We Love",
                                         sapply(details, `[`, 3),
                                         sapply(details, `[`, 2))))) %>%
  mutate(location = ifelse((sapply(details, `[`, 1) == "Zine Quest" | sapply(details, `[`, 1) == "Make 100" | sapply(details, `[`, 1) == "Witchstarter" | sapply(details, `[`, 1) == "Long Story Short" | sapply(details, `[`, 1) == "Heartstrings & Hardbacks"),
                           ifelse((state == "Funding Unsuccessful" | state == "Funding Suspended" | state == "Funding Canceled"),
                                  ifelse(sapply(details, `[`, 2) == "Project We Love",
                                         sapply(details, `[`, 4),
                                         sapply(details, `[`, 3)),
                                  ifelse(sapply(details, `[`, 2) == "Project We Love",
                                         sapply(details, `[`, 3),
                                         sapply(details, `[`, 2))),
                           ifelse((state == "Funding Unsuccessful" | state == "Funding Suspended" | state == "Funding Canceled"),
                                  ifelse(sapply(details, `[`, 1) == "Project We Love",
                                         sapply(details, `[`, 3),
                                         sapply(details, `[`, 2)),
                                  ifelse(sapply(details, `[`, 1) == "Project We Love",
                                         sapply(details, `[`, 2),
                                         sapply(details, `[`, 1))))) %>%
  mutate(currency = str_extract(funded, "^([a-z]|[A-Z])*(\\p{Sc})*")) %>%
  mutate(funded = str_extract(funded, "[0-9]*(,([0-9])*)*$")) %>%
  mutate(goal = str_extract(goal, "[0-9]*(,([0-9])*)*$")) %>%
  mutate(duration = str_extract(duration, "[0-9]+")) %>%
  mutate(reward_stages = sapply(reward, calculate_length)) %>%
  mutate(country = map_chr(str_split(location, ", "), tail, 1)) %>%
  left_join(data_us_states, by = c("country" = "abbreviation")) %>%
  mutate(country = if_else(is.na(state.y), country, "USA")) %>%
  mutate(country = ifelse(country == "UK", "United Kingdom", country)) %>%
  mutate(country = ifelse(country == "AU", "Australia", country)) %>%
  mutate(country = ifelse(country == "NZ", "New Zealand", country)) %>%
  left_join(data_continents, by = c("country" = "Entity")) %>%
  mutate(Continent = if_else(country == "USA", "North America", Continent)) %>%
  mutate(start_date = dmy(gsub("^(\\w+) (\\d+) (\\d+)$", "\\2 \\1 \\3", start_date))) %>%
  mutate(end_date = dmy(gsub("^(\\w+) (\\d+) (\\d+)$", "\\2 \\1 \\3", end_date))) %>%
  mutate(backers = str_extract(backers, "^[0-9]*(,([0-9])*)?")) %>%
  mutate(backers = gsub(",", "", backers)) %>%
  mutate(funded = as.numeric(gsub(",", "", funded))) %>%
  mutate(goal = as.numeric(gsub(",", "", goal))) %>%
  mutate(duration = as.numeric(duration)) %>%
  mutate(backers = as.numeric(backers)) %>%
  mutate(images = images - video_description) %>%
  arrange(end_date) %>%
  left_join(exchange_aud, by = c("end_date" = "Date")) %>%
  mutate(Price_AUD = ifelse(is.na(Price_AUD), zoo::na.locf(Price_AUD), Price_AUD)) %>%
  left_join(exchange_cad, by = c("end_date" = "Date")) %>%
  mutate(Price_CAD = ifelse(is.na(Price_CAD), zoo::na.locf(Price_CAD), Price_CAD)) %>%
  left_join(exchange_chf, by = c("end_date" = "Date")) %>%
  mutate(Price_CHF = ifelse(is.na(Price_CHF), zoo::na.locf(Price_CHF), Price_CHF)) %>%
  left_join(exchange_dkk, by = c("end_date" = "Date")) %>%
  mutate(Price_DKK = ifelse(is.na(Price_DKK), zoo::na.locf(Price_DKK), Price_DKK)) %>%
  left_join(exchange_eur, by = c("end_date" = "Date")) %>%
  mutate(Price_EUR = ifelse(is.na(Price_EUR), zoo::na.locf(Price_EUR), Price_EUR)) %>%
  left_join(exchange_gbp, by = c("end_date" = "Date")) %>%
  mutate(Price_GBP = ifelse(is.na(Price_GBP), zoo::na.locf(Price_GBP), Price_GBP)) %>%
  left_join(exchange_hkd, by = c("end_date" = "Date")) %>%
  mutate(Price_HKD = ifelse(is.na(Price_HKD), zoo::na.locf(Price_HKD), Price_HKD)) %>%
  left_join(exchange_jpy, by = c("end_date" = "Date")) %>%
  mutate(Price_JPY = ifelse(is.na(Price_JPY), zoo::na.locf(Price_JPY), Price_JPY)) %>%
  left_join(exchange_mxn, by = c("end_date" = "Date")) %>%
  mutate(Price_MXN = ifelse(is.na(Price_MXN), zoo::na.locf(Price_MXN), Price_MXN)) %>%
  left_join(exchange_nok, by = c("end_date" = "Date")) %>%
  mutate(Price_NOK = ifelse(is.na(Price_NOK), zoo::na.locf(Price_NOK), Price_NOK)) %>%
  left_join(exchange_nzd, by = c("end_date" = "Date")) %>%
  mutate(Price_NZD = ifelse(is.na(Price_NZD), zoo::na.locf(Price_NZD), Price_NZD)) %>%
  left_join(exchange_sek, by = c("end_date" = "Date")) %>%
  mutate(Price_SEK = ifelse(is.na(Price_SEK), zoo::na.locf(Price_SEK), Price_SEK)) %>%
  left_join(exchange_pln, by = c("end_date" = "Date")) %>%
  mutate(Price_PLN = ifelse(is.na(Price_PLN), zoo::na.locf(Price_PLN), Price_PLN)) %>%
  left_join(exchange_sgd, by = c("end_date" = "Date")) %>%
  mutate(Price_SGD = ifelse(is.na(Price_SGD), zoo::na.locf(Price_SGD), Price_SGD)) %>%
  mutate(funded_usd = ifelse(currency == "€", round(funded*Price_EUR, 2),
                             ifelse(currency == "MX$", round(funded*Price_MXN, 2),
                                    ifelse(currency == "£", round(funded*Price_GBP, 2),
                                           ifelse(currency == "CA$", round(funded*Price_CAD, 2),
                                                  ifelse(currency == "¥", round(funded*Price_JPY, 2),
                                                         ifelse(currency == "HK$", round(funded*Price_HKD, 2),
                                                                ifelse(currency == "DKK", round(funded*Price_DKK, 2),
                                                                       ifelse(currency == "PLN", round(funded*Price_PLN, 2),
                                                                              ifelse(currency == "AU$", round(funded*Price_AUD, 2),
                                                                                     ifelse(currency == "CHF", round(funded*Price_CHF, 2),
                                                                                            ifelse(currency == "NZ$", round(funded*Price_NZD, 2),
                                                                                                   ifelse(currency == "S$", round(funded*Price_SGD, 2),
                                                                                                          ifelse(currency == "NOK", round(funded*Price_NOK, 2),
                                                                                                                 ifelse(currency == "SEK", round(funded*Price_SEK, 2),
                                                                                                                        ifelse(currency == "US$", round(funded*1, 2),
                                                                                                                               ifelse(currency == "$", round(funded*1, 2), NA))))))))))))))))) %>%
  mutate(goal_usd = ifelse(currency == "€", round(goal*Price_EUR, 2),
                             ifelse(currency == "MX$", round(goal*Price_MXN, 2),
                                    ifelse(currency == "£", round(goal*Price_GBP, 2),
                                           ifelse(currency == "CA$", round(goal*Price_CAD, 2),
                                                  ifelse(currency == "¥", round(goal*Price_JPY, 2),
                                                         ifelse(currency == "HK$", round(goal*Price_HKD, 2),
                                                                ifelse(currency == "DKK", round(goal*Price_DKK, 2),
                                                                       ifelse(currency == "PLN", round(goal*Price_PLN, 2),
                                                                              ifelse(currency == "AU$", round(goal*Price_AUD, 2),
                                                                                     ifelse(currency == "CHF", round(goal*Price_CHF, 2),
                                                                                            ifelse(currency == "NZ$", round(goal*Price_NZD, 2),
                                                                                                   ifelse(currency == "S$", round(goal*Price_SGD, 2),
                                                                                                          ifelse(currency == "NOK", round(goal*Price_NOK, 2),
                                                                                                                 ifelse(currency == "SEK", round(goal*Price_SEK, 2), 
                                                                                                                        ifelse(currency == "US$", round(goal*1, 2),
                                                                                                                               ifelse(currency == "$", round(goal*1, 2), NA))))))))))))))))) %>%
  mutate(successful = ifelse(funded >= goal, 1, 0)) %>%
  mutate(blurb_length = str_count(description, "\\S+")) %>%
  select(-c(state.y, Code, Year))


# import comment data from Kickstarter projects
data_kickstarter_comments1 <- read_csv("v1_0-199/raw-data-comments.csv")
data_kickstarter_comments2 <- read_csv("v2_200-2199/raw-data-comments.csv")
data_kickstarter_comments3 <- read_csv("v3_2200-2699/raw-data-comments.csv")
data_kickstarter_comments4 <- read_csv("v4_2700-3199/raw-data-comments.csv")
data_kickstarter_comments5 <- read_csv("v5_3200-3699/raw-data-comments.csv")
data_kickstarter_comments6 <- read_csv("v6_3700-4199_fail/raw-data-comments.csv")
data_kickstarter_comments7 <- read_csv("v7_4200-5200/raw-data-comments.csv")
data_kickstarter_comments8 <- read_csv("v8_5200-10200/raw-data-comments.csv")
data_kickstarter_comments9 <- read_csv("v9_10200-11950_fail/raw-data-comments.csv")
data_kickstarter_comments10 <- read_csv("v10_11950-13450/raw-data-comments.csv")
data_kickstarter_comments11 <- read_csv("v11_13450-23450/raw-data-comments.csv")
data_kickstarter_comments12 <- read_csv("v12_23450-27450/raw-data-comments.csv")


# combine these datasets to a single dataset
data_project_comments <- rbind(data_kickstarter_comments1, data_kickstarter_comments2, data_kickstarter_comments3, data_kickstarter_comments4,
                         data_kickstarter_comments5, data_kickstarter_comments6, data_kickstarter_comments7, data_kickstarter_comments8,
                         data_kickstarter_comments9, data_kickstarter_comments10, data_kickstarter_comments11, data_kickstarter_comments12) %>% select(kickstarter_link, comment_description = "comment-description", text, sentiment)


# remove missing and duplicated values
data_project_comments <- data_project_comments %>% na.omit() %>%
                         distinct(kickstarter_link, .keep_all = TRUE)


# combine the comment dataset with the campaign dataset
data_combine_campaign_comments <- data_project_campaign %>%
  left_join(data_project_comments, by = "kickstarter_link") %>%
  subset(!(count_comments > 0 & is.na(text))) %>%
  mutate(comment_description = ifelse(is.na(comment_description), "None", comment_description)) %>%
  mutate(text = ifelse(is.na(text), "None", text)) %>%
  mutate(sentiment = ifelse(is.na(sentiment), 0.00000000, sentiment))


# import creator data from Kickstarter projects
data_kickstarter_creator1 <- read_csv("v1_0-199/raw-data-creator.csv")
data_kickstarter_creator2 <- read_csv("v2_200-2199/raw-data-creator.csv")
data_kickstarter_creator3 <- read_csv("v3_2200-2699/raw-data-creator.csv")
data_kickstarter_creator4 <- read_csv("v4_2700-3199/raw-data-creator.csv")
data_kickstarter_creator5 <- read_csv("v5_3200-3699/raw-data-creator.csv")
data_kickstarter_creator6 <- read_csv("v6_3700-4199_fail/raw-data-creator.csv")
data_kickstarter_creator7 <- read_csv("v7_4200-5200/raw-data-creator.csv")
data_kickstarter_creator8 <- read_csv("v8_5200-10200/raw-data-creator.csv")
data_kickstarter_creator9 <- read_csv("v9_10200-11950_fail/raw-data-creator.csv")
data_kickstarter_creator10 <- read_csv("v10_11950-13450/raw-data-creator.csv")
data_kickstarter_creator11 <- read_csv("v11_13450-23450/raw-data-creator.csv")
data_kickstarter_creator12 <- read_csv("v12_23450-27450/raw-data-creator.csv")


# combine these datasets
data_project_creator <- rbind(data_kickstarter_creator1, data_kickstarter_creator2, data_kickstarter_creator3, data_kickstarter_creator4,
                        data_kickstarter_creator5, data_kickstarter_creator6, data_kickstarter_creator7, data_kickstarter_creator8,
                        data_kickstarter_creator9, data_kickstarter_creator10, data_kickstarter_creator11, data_kickstarter_creator12)


# remove missing values
data_project_creator <- data_project_creator %>% na.omit()


# formatting of the previous project column (urls)
format_previous_projects_urls <- function(input_string) {
  # remove square brackets
  cleaned_input <- gsub("\\[|\\]", "", input_string)
  # split the list elements
  list_elements <- strsplit(cleaned_input, ", ")[[1]]
  # extract the urls of the previous created Kickstarter projects
  links <- gsub("^'(.*)'.*$", "\\1", list_elements[grep("^'http", list_elements)])
}

format_previous_projects_funded <- function(input_string) {
  # remove square brackets
  cleaned_input <- gsub("\\[|\\]", "", input_string)
  # split the list elements
  list_elements <- strsplit(cleaned_input, ", ")[[1]]
  # extract the funding information of the previous projects
  funding_info <- gsub("^'Ended • (\\d+)% funded'.*$", "\\1", list_elements[grep("^'Ended", list_elements)], perl = TRUE)
  # convert numbers to numeric datatype
  funding_numeric <- as.numeric(funding_info)
}

# clean the creator dataset
data_project_creator <- data_project_creator %>%
  mutate(links = map(created_projects, format_previous_projects_urls)) %>%
  mutate(previous_success = map(created_projects, format_previous_projects_funded)) %>%
  mutate(backed_projects = as.numeric(str_extract(backed_projects, "\\b[0-9]+\\b")))


# count the previous (successful) created projects
for (i in seq_along(data_project_creator$links)) {
  if (is.vector(data_project_creator$links[[i]])) {
    # iterate through every url in data_creator_v2_prep$links[[i]]
    for (j in seq_along(data_project_creator$links[[i]])) {
      link <- data_project_creator$links[[i]][j]
      # search for a match in the base dataset
      match_index <- which(data_combine_campaign_comments$kickstarter_link %in% link)
      # if there is a match
      if (length(match_index) > 0) {
        remaining_links <- length(data_project_creator$links[[i]]) - j
        data_combine_campaign_comments[match_index, paste0("linked_value", 1:length(link))] <- rep(
          unlist(link),
          length(match_index)
        )
        data_combine_campaign_comments[match_index, "previous_projects"] <- remaining_links
        data_combine_campaign_comments[match_index, "creator_link"] <- data_project_creator$creator_link[i]
        data_combine_campaign_comments[match_index, "backed_projects"] <- data_project_creator$backed_projects[i]
        # if there is no previous project
        if ((j+1) > length(data_project_creator$previous_success[[i]])) {
          sum_previous_success <- 0
        } else {
          # else sum all successful previous projects
          sum_previous_success <- sum(data_project_creator$previous_success[[i]][(j+1):length(data_project_creator$previous_success[[i]])] >= 100)
        }
        data_combine_campaign_comments[match_index, "previous_success"] <- sum_previous_success
      }
    }
  }
}


# remove missing values
data_combine_campaign_comments <- data_combine_campaign_comments %>%
  na.omit()


# import community data from Kickstarter projects
data_kickstarter_community1 <- read_csv("v1_0-199/raw-data-community.csv")
data_kickstarter_community2 <- read_csv("v2_200-2199/raw-data-community.csv")
data_kickstarter_community3 <- read_csv("v3_2200-2699/raw-data-community.csv")
data_kickstarter_community4 <- read_csv("v4_2700-3199/raw-data-community.csv")
data_kickstarter_community5 <- read_csv("v5_3200-3699/raw-data-community.csv")
data_kickstarter_community6 <- read_csv("v6_3700-4199_fail/raw-data-community.csv")
data_kickstarter_community7 <- read_csv("v7_4200-5200/raw-data-community.csv")
data_kickstarter_community8 <- read_csv("v8_5200-10200/raw-data-community.csv")
data_kickstarter_community9 <- read_csv("v9_10200-11950_fail/raw-data-community.csv")
data_kickstarter_community10 <- read_csv("v10_11950-13450/raw-data-community.csv")
data_kickstarter_community11 <- read_csv("v11_13450-23450/raw-data-community.csv")
data_kickstarter_community12 <- read_csv("v12_23450-27450/raw-data-community.csv")


# combine these datasets
data_kickstarter_community <- rbind(data_kickstarter_community1, data_kickstarter_community2, data_kickstarter_community3, data_kickstarter_community4,
                              data_kickstarter_community5, data_kickstarter_community6, data_kickstarter_community7, data_kickstarter_community8,
                              data_kickstarter_community9, data_kickstarter_community10, data_kickstarter_community11, data_kickstarter_community12)


# remove missing and duplicated values
data_kickstarter_community <- data_kickstarter_community %>%
  mutate(new_backers = as.numeric(gsub(",", "", new_backers))) %>%
  mutate(experienced_backers = as.numeric(gsub(",", "", experienced_backers))) %>%
  na.omit() %>%
  distinct(kickstarter_link, .keep_all = TRUE)


# combine this dataset with the previous combined dataset
data_combine_campaign_comments_community <- data_combine_campaign_comments %>%
  left_join(data_kickstarter_community, by = "kickstarter_link")


# remove missing values (<10 backers)
data_combine_campaign_comments_community <- data_combine_campaign_comments_community %>%
  subset(backers.x >= 10) %>%
  na.omit()


# import Kicktraq dataset
data_project_kicktraq <- read_csv("kicktraq_data/ended_projects_all.csv") %>%
  select(kicktraq = url, category_kicktraq = category, updates_kicktraq = updates) %>%
  mutate(category_kicktraq = ifelse(category_kicktraq == "sculpture", "art", ifelse(category_kicktraq == "social practice", "art", category_kicktraq)))

data_project_kicktraq$kickstarter_link <- gsub("kicktraq", "kickstarter", data_project_kicktraq$kicktraq)

data_project_kicktraq$category_kicktraq <- paste(toupper(substring(data_project_kicktraq$category_kicktraq, 1, 1)), substring(data_project_kicktraq$category_kicktraq, 2), sep = "")


# join each of the both final datasets to the Kicktraq dataset
# version with all projects
data_final_all <- data_combine_campaign_comments %>%
  left_join(data_project_kicktraq, by = "kickstarter_link") %>%
  na.omit()

saveRDS(data_final_all, file = "final_data/data_final_all.rds")
data_final_all <- readRDS("final_data/data_final_all.rds")

# version with projects which have more than 9 backers
data_final_subset <- data_combine_campaign_comments_community %>%
  left_join(data_project_kicktraq, by = "kickstarter_link") %>%
  na.omit()

saveRDS(data_final_subset, file = "final_data/data_final_subset.rds")
data_final_subset <- readRDS("final_data/data_final_subset.rds")


# select for regression important variables and save them to a .dta format (Stata)
data_final_all_stata <- data_final_all %>%
  select(
    backers, funded_usd, # independent variables
    success = successful, state = state.x, start_date, end_date, duration, goal_usd, continent = Continent, blurb_length, video_header, videos_description = video_description, images_description = images, reward_stages, # project-specific
    creator_verified = verified, websites_linked = websites, updates_all = count_updates, updates_period = updates_kicktraq, backed_projects, previous_projects, previous_success, # creator-specific
    team_favorite, open_call, category = category_kicktraq, subcategory = category, # Kickstarter-specific
    comments = count_comments, sentiment # backer-specific
  )
write.dta(data_final_all_stata, "final_data/data_final_all_stata.dta")

data_final_subset_stata <- data_final_subset %>%
  select(
    backers = backers.x, new_backers, experienced_backers, funded_usd, # independent variables
    success = successful, state = state.x, start_date, end_date, duration, goal_usd, continent = Continent, blurb_length, video_header, videos_description = video_description, images_description = images, reward_stages, # project-specific
    creator_verified = verified, websites_linked = websites, updates_all = count_updates, updates_period = updates_kicktraq, backed_projects, previous_projects, previous_success, # creator-specific
    team_favorite, open_call, category = category_kicktraq, subcategory = category, # Kickstarter-specific
    comments = count_comments, sentiment # backer-specific
  )
write.dta(data_final_subset_stata, "final_data/data_final_subset_stata.dta")


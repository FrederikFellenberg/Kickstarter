library(tidyverse)
library(MASS)
library(AER)
library(DHARMa)
library(glmmTMB)

data_subset <- readRDS("final_data/data_final_subset.rds")

data_subset$lnGoal <- log(data_subset$goal_usd)
data_subset$open_call_bin <- ifelse(data_subset$open_call == "None", 0, 1)

data_truncated <- subset(data_subset, count_comments<1500)

############################# Poisson regression model #########################

summary(model.prm.old <- glm(experienced_backers ~ open_call_bin + lnGoal + duration + blurb_length + video_header +
                           video_description + images + reward_stages + websites +
                           updates_kicktraq + backed_projects + previous_success + count_comments + sentiment +
                           as.factor(category_kicktraq), 
                         family="poisson", data=data_truncated))
dispersiontest(model.prm.old)
# overdispersion

summary(model.prm.new <- glm(experienced_backers ~ open_call_bin + lnGoal + duration + blurb_length + video_header +
                           video_description + images + reward_stages + websites +
                           updates_kicktraq + backed_projects + previous_success + count_comments + sentiment +
                           as.factor(category_kicktraq), 
                         family="poisson", data=data_truncated))
dispersiontest(model.prm.new)
# overdispersion

########################### Negative Binomial Regression #######################

summary(model.nbrm.old <- glm.nb(experienced_backers ~ open_call_bin + lnGoal + duration + blurb_length + video_header +
                           video_description + images + reward_stages + websites +
                           updates_kicktraq + backed_projects + previous_success + count_comments + sentiment +
                           as.factor(category_kicktraq), 
                         data=data_truncated))
plot(model.nbrm.old)
simulationOutput.old <- simulateResiduals(fittedModel = model.nbrm.old, plot = F)
testZeroInflation(simulationOutput.old)
# no zero inflation

summary(model.nbrm.new <- glm.nb(new_backers ~ open_call_bin + lnGoal + duration + blurb_length + video_header +
                               video_description + images + reward_stages + websites +
                               updates_kicktraq + backed_projects + previous_success + count_comments + sentiment +
                               as.factor(category_kicktraq), 
                             data=data_truncated))
plot(model.nbrm.new)
simulationOutput.new <- simulateResiduals(fittedModel = model.nbrm.new, plot = F)
testZeroInflation(simulationOutput.new)
# no zero inflation

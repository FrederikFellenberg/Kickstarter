# import packages (first install scrapy with "pip install scrapy")
from scrapy.spiders import CrawlSpider, Rule
from scrapy.linkextractors import LinkExtractor
from datetime import datetime
import scrapy
import re
import csv
import os
import requests

# write a function to convert dates
def convert_date(date_str):
    month_mapping = {
        'January': '01',
        'February': '02',
        'March': '03',
        'April': '04',
        'May': '05',
        'June': '06',
        'July': '07',
        'August': '08',
        'September': '09',
        'October': '10',
        'November': '11',
        'December': '12'
    }

    parts = date_str.split()
    day = parts[0][:-2] if parts[0].endswith(('st', 'nd', 'rd', 'th')) else parts[0]
    month = month_mapping.get(parts[2])
    year = parts[3]

    day = day.zfill(2)

    return f"{day}.{month}.{year}"

# define the spider
class CrawlingSpider(CrawlSpider):

    # initialize the spider
    name = "mycrawler"
    allowed_domains = ["kicktraq.com"]
    start_urls = [
        f"https://www.kicktraq.com/search/?page={page}&find=is:closed%20is:unsuccessful" # successful if you want to
        # crawl the successful projects
        for page in range(0, 10, -1) # here you can define the range of pages which you want to crawl
    ]
    
    rules = (
        Rule(LinkExtractor(allow="projects/", deny="[^/]$"), callback="parse_item"),
    )

    # declare function to extract funded amount and the corresponding currency
    def extract_currency_and_reached_amount(self, text):
        amount_match = re.search(r'(?:Funded:|Funding:)?(\D*\s*[\d,]+)', text)
        if amount_match:
            currency_match = re.search(r'[^\d,]+', amount_match.group(1))
            currency = currency_match.group(0).strip() if currency_match else ""
            return currency, amount_match.group(1).replace(currency, '').replace(',', '')
        else:
            return "", "0"

    # declare a function to extract the goal amount
    def extract_target_amount(self, text, currency):
        numbers = re.findall(r'\d+(?:,\d+)?', text)

        return numbers[-1].replace(',', '') if len(numbers) > 0 else "0"

    # declare a function to scrape the page
    def parse_item(self, response):
        
        if response.url.startswith("http://") or response.url == 'https://www.kicktraq.com/projects/':
            return
        current_url = response.url
        
        datelink_elements = response.css('a.datelink')

        datelink = datelink_elements[0] if len(datelink_elements) > 1 else None
        if datelink:
            title_text = datelink.css("::attr(title)").get()
            if title_text:
                start_date_raw = " ".join(title_text.split()[1:]).split("@")[0].strip()
                start_date = convert_date(start_date_raw)

        other_datelink = datelink_elements[1] if len(datelink_elements) > 1 else None
        if other_datelink:
            other_title_text = other_datelink.css('::attr(title)').get()
            if other_title_text:
                end_date_raw = ' '.join(other_title_text.split()[1:]).split('@')[0].strip()
                end_date = convert_date(end_date_raw)
                
            
        location = response.css("div#project-title span::text").get()
        first_comma_index = location.find(',')
        if first_comma_index != -1:
            country_code = location[first_comma_index + 1:].strip()
            by_index = country_code.find('by ')
            if by_index != -1:
                country_code = country_code[:by_index].strip()
            
        else:
            country_code = "" 
            
            
        funded_text = response.xpath('normalize-space(//div[@id="project-info-text"]/text()[contains(., "Funding:") '
                                     'or contains(., "Funded:")])').get()
        currency, reached_amount = self.extract_currency_and_reached_amount(funded_text)

        target_text_xpath = ('normalize-space(//div[@id="project-info-text"]/text()[contains(., "of {}")])'.
                             format(currency))
        target_amount = self.extract_target_amount(response.xpath(target_text_xpath).get(), currency)


        href = response.xpath('//a[contains(@href, "/categories/")]/@href').get()
        if href:
            parts = href.split('/')
            category = parts[2] if len(parts) > 2 else ""
        else:
            category = ""
            
            
        project_status = response.css("div#pledgilizer-disabled::text").get()
        if project_status == "funding period ended":
            status = "ended"
        elif project_status == "project cancelled":
            status = "cancelled"
        elif project_status == "project deleted":
            status = "deleted"
        else: 
            status = "active"
            
            
        updates_count = len(response.css("div.newscolumn div.infoblock"))

        data_to_write = {
            "success": 0,
            "url": current_url,
            "start_date": start_date,
            "end_date": end_date,
            "duration": int(response.xpath('normalize-space(//div[@id="project-info-text"]/text()[starts-with'
                                           '(normalize-space(.), "(")])').get().replace("days", "").strip("()")),
            "backers": int(response.xpath('normalize-space(//div[@id="project-info-text"]/text()[starts-with'
                                          '(normalize-space(.), "Backers:")])').get().replace("Backers:", "").strip()),
            "funded": float(reached_amount),
            "goal": float(target_amount),
            "currency": currency,
            "category": category,
            "country/state": country_code,
            "status": status,
            "updates": int(updates_count)
        }
        
        self.write_to_csv(data_to_write)

    # write the data to a csv file
    def write_to_csv(self, data):

        path = "xy"  # define your path
        csv_file_path = f"{path}\\unsuccessful_ended_projects.csv"
        
        is_file_exists = os.path.isfile(csv_file_path)

        with open(csv_file_path, mode='a', newline='', encoding='utf-8') as file:
            fieldnames = data.keys()
            writer = csv.DictWriter(file, fieldnames=fieldnames)

            if not is_file_exists:
                writer.writeheader()

            writer.writerow(data)    
